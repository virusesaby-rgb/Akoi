package com.akoi.recorder

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var wantMic = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.parseColor("#0E0E12")
        window.navigationBarColor = Color.parseColor("#1A1A21")
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "AkoiNative")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
        RecorderService.listener = { st ->
            runOnUiThread { web.evaluateJavascript("window.onAkoi&&window.onAkoi('$st')", null) }
        }
    }

    inner class Bridge {
        @JavascriptInterface fun start(mic: Boolean) { runOnUiThread { begin(mic) } }
        @JavascriptInterface fun pause() { send("pause") }
        @JavascriptInterface fun resume() { send("resume") }
        @JavascriptInterface fun stop() { send("stop") }
    }

    private fun send(action: String) {
        startService(Intent(this, RecorderService::class.java).setAction(action))
    }

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun begin(mic: Boolean) {
        wantMic = mic
        val need = ArrayList<String>()
        if (mic && !granted(Manifest.permission.RECORD_AUDIO)) need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isEmpty()) askCapture() else requestPermissions(need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        askCapture()
    }

    private fun askCapture() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), 2)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 2) return
        if (resultCode == RESULT_OK && data != null) {
            val mic = wantMic && granted(Manifest.permission.RECORD_AUDIO)
            val i = Intent(this, RecorderService::class.java).setAction("start")
                .putExtra("code", resultCode).putExtra("data", data).putExtra("mic", mic)
            startForegroundService(i)
        } else {
            web.evaluateJavascript("window.onAkoi&&window.onAkoi('denied')", null)
        }
    }
}
