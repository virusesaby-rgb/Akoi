package com.akoi.recorder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RecorderService : Service() {
    companion object {
        var listener: ((String) -> Unit)? = null
        @Volatile var running = false
    }

    private var projection: MediaProjection? = null
    private var recorder: MediaRecorder? = null
    private var vd: VirtualDisplay? = null
    private var pfd: ParcelFileDescriptor? = null
    private var uri: Uri? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        when (i?.action) {
            "start" -> start(i)
            "pause" -> if (running) { recorder?.pause(); listener?.invoke("paused") }
            "resume" -> if (running) { recorder?.resume(); listener?.invoke("resumed") }
            "stop" -> stop(false)
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun start(i: Intent) {
        val mic = i.getBooleanExtra("mic", false)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("akoi", "Grabación", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(this, 1,
            Intent(this, RecorderService::class.java).setAction("stop"), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "akoi")
            .setContentTitle("Akoi está grabando")
            .setContentText("Pulsa Detener para guardar el vídeo")
            .setSmallIcon(android.R.drawable.presence_video_online)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_media_pause), "Detener", stopPi).build())
            .build()
        var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        if (mic) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        startForeground(1, n, type)
        try {
            val code = i.getIntExtra("code", 0)
            val data = i.getParcelableExtra<Intent>("data")!!
            val mp = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
            projection = mp
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stop(false) }
            }, Handler(Looper.getMainLooper()))

            val dm = resources.displayMetrics
            val k = minOf(1f, 1080f / minOf(dm.widthPixels, dm.heightPixels))
            val w = (dm.widthPixels * k).toInt() / 2 * 2
            val h = (dm.heightPixels * k).toInt() / 2 * 2

            val name = "Akoi-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".mp4"
            val cv = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Akoi")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)
            pfd = contentResolver.openFileDescriptor(uri!!, "w")

            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            if (mic) r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setOutputFile(pfd!!.fileDescriptor)
            r.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            if (mic) { r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC); r.setAudioEncodingBitRate(128000); r.setAudioSamplingRate(44100) }
            r.setVideoSize(w, h)
            r.setVideoFrameRate(30)
            r.setVideoEncodingBitRate(8_000_000)
            r.prepare()
            recorder = r

            vd = mp.createVirtualDisplay("akoi", w, h, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null)
            running = true
            r.start()
            listener?.invoke("recording")
        } catch (e: Exception) {
            running = true
            stop(true)
        }
    }

    private fun stop(failed: Boolean) {
        if (!running) { stopSelf(); return }
        running = false
        try { recorder?.stop() } catch (e: Exception) { }
        try { recorder?.release() } catch (e: Exception) { }
        try { vd?.release() } catch (e: Exception) { }
        try { projection?.stop() } catch (e: Exception) { }
        try { pfd?.close() } catch (e: Exception) { }
        uri?.let {
            if (failed) contentResolver.delete(it, null, null)
            else contentResolver.update(it, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
        }
        recorder = null; vd = null; projection = null; pfd = null; uri = null
        listener?.invoke(if (failed) "error" else "saved")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }
}
